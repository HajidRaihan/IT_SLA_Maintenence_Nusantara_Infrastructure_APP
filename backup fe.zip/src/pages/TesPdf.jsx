import React from 'react';
import Jadwalpdf from '../components/FormActivity/Jadwalpdf';

const TesPdf = () => {
  return (
    <div>
      <Jadwalpdf />
    </div>
  );
};

export default TesPdf;
