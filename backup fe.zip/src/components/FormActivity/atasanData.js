export const atasanData = [
  {
    id: 1,
    name: 'Mashuri Said',
    ttd: './ttd1.jpg',
  },
  {
    id: 2,
    name: 'Hurja',
    ttd: './ttd2.jpg',
  },
];
